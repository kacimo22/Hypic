# Hypic

**Hypic** is a Python library that extends the existing `aioquic` QUIC implementation to provide **post-quantum security** while maintaining **backward compatibility**.  

## Acknowledgments

Hypic is based on and extends the **aioquic** QUIC implementation by Jeremy Lainé and contributors.

---

The library introduces a **hybrid key establishment** combining classical ECDHE with **ML-KEM (Kyber)** to protect session keys against future quantum adversaries.  
It supports **two types of clients**:

- **Legacy clients**: use standard QUIC/TLS 1.3 mechanisms.  
- **Post-quantum–aware clients**: negotiate hybrid classical–post-quantum key exchange and post-quantum session resumption.

Hypic also integrates **Catalyst certificates** for **post-quantum authentication**, avoiding reliance on classical-only signatures while remaining interoperable with existing certificate infrastructures.

---

## Requirements

- Python >= 3.9  
- OpenSSL >= 3.5  
- pip dependencies will be installed automatically  

> ⚠️ Hypic will check the OpenSSL version at runtime and exit if it is below 3.5.

---

## Installation

### From PyPI (after release)

```bash
pip install hypic

## Runing the protocol
The server_config.json contains the server configuration.
1- Get into the Hypic directory
2- Run the command: source .venv/bin/activate
3- pip install -e .

1- Run the server: python3 examples/http3_server.py --catalyst-config server_config.json
2- To run a legacy client: python3.10 examples/http3_client.py --insecure  https://localhost:4433/ 

## -------------------
To run a post
