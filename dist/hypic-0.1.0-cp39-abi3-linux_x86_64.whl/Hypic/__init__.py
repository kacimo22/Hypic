from .__version__ import __version__
import ssl
import sys

if tuple(map(int, ssl.OPENSSL_VERSION_INFO[:3])) < (3, 5, 0):
    sys.exit("Hypic requires OpenSSL >= 3.5")
